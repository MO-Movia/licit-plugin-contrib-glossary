import { TextSelection } from 'prosemirror-state';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { updateIndentLevel } from './updateIndentLevel';
export class IndentCommand extends UICommand {
    _delta;
    constructor(delta) {
        super();
        this._delta = delta;
    }
    isActive = (_state) => {
        return true;
    };
    execute = (state, dispatch, _view) => {
        const { selection, schema } = state;
        let { tr } = state;
        tr = tr.setSelection(selection);
        const trx = updateIndentLevel(state, tr, schema, this._delta, _view);
        if (trx.docChanged) {
            // set the value of overriddenIndent to true if the user override the indent style.
            const nodePos = trx.tr.selection.$from.before(1);
            const paraNode = trx.tr.doc.nodeAt(nodePos);
            if (paraNode) {
                if (Number(selection.$head.parent.attrs.indent) !== Number(paraNode.attrs.indent)) {
                    const newAttrs = {
                        ...paraNode.attrs,
                        overriddenIndent: true,
                        overriddenIndentValue: paraNode.attrs.indent
                    };
                    tr = tr.setNodeMarkup(nodePos, null, newAttrs);
                }
            }
            dispatch?.(trx.tr);
        }
        return true;
    };
    // [FS] IRAD-1087 2020-11-11
    // New method to execute new styling implementation for indent
    executeCustom = (state, tr, from, to) => {
        const { schema } = state;
        tr = tr.setSelection(TextSelection.create(tr.doc, from, to));
        const trx = updateIndentLevel(state, tr, schema, this._delta, null);
        return trx.tr;
    };
    executeCustomStyleForTable = (state, tr, _from, _to) => {
        const { schema } = state;
        const trx = updateIndentLevel(state, tr, schema, this._delta, null);
        return trx.tr;
    };
    waitForUserInput = (_state, _dispatch, _view, _event) => {
        return Promise.resolve(undefined);
    };
    executeWithUserInput = (_state, _dispatch, _view, _inputs) => {
        return false;
    };
    cancel() {
        return null;
    }
    renderLabel() {
        return null;
    }
}
