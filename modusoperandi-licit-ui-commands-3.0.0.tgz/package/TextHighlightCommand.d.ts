import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { EditorState } from 'prosemirror-state';
import { EditorView } from 'prosemirror-view';
import { Transform } from 'prosemirror-transform';
export declare class TextHighlightCommand extends UICommand {
    _popUp: unknown;
    _color: string;
    constructor(color?: string);
    isEnabled: (state: EditorState) => boolean;
    waitForUserInput: (state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, event?: Event) => Promise<undefined>;
    executeWithUserInput: (state: EditorState, dispatch?: (tr: Transform) => void, _view?: EditorView, color?: {
        color: any;
        selectedOption: any;
    }) => boolean;
    executeCustom: (state: EditorState, tr: Transform, from: number, to: number) => Transform;
    executeCustomStyleForTable: (state: EditorState, tr: Transform, from: number, to: number) => Transform;
    cancel(): void;
    isActive(): boolean;
    renderLabel(): any;
}
