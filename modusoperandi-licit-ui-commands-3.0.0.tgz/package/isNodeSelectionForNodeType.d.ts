import { Selection } from 'prosemirror-state';
import { Node, NodeType } from 'prosemirror-model';
export declare function isNodeSelectionForNodeType(selection: Selection, nodeType: NodeType): boolean;
export declare function getSelectionRange(selection: Selection): {
    from: number;
    to: number;
};
export declare function getSelectedCellPositions(selection: Selection): number[];
export declare function isColumnCellSelected(selection: Selection): boolean;
export declare function findParagraphsInNode(node: Node, pos: number, callback: (paragraphNode: Node, paragraphPos: number) => void): void;
