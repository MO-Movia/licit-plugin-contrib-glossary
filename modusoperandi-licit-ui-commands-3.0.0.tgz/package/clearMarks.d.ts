import { Mark, Node, Schema } from 'prosemirror-model';
import { Transform } from 'prosemirror-transform';
import { Style } from './runtime.service';
export declare function clearMarks(tr: Transform, schema: Schema): Transform;
/**
 * Recursively extracts paragraphs with styleName='Normal' from a given node.
 */
export declare function extractParagraphs(node: Node, normalParagraphs: Node[], otherParagraphs: Node[]): void;
export declare function comapreMarks(style: Style, mark: Mark, marksToAdd: any, pos: number, node: Node, schema: Schema): boolean;
export declare function clearHeading(tr: Transform, schema: Schema): Transform;
