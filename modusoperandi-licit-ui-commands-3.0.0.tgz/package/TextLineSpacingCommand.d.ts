import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { EditorState } from 'prosemirror-state';
import { EditorView } from 'prosemirror-view';
import { Schema } from 'prosemirror-model';
import { Transform } from 'prosemirror-transform';
import * as React from 'react';
export declare function setTextLineSpacing(tr: Transform, schema: Schema, lineSpacing?: string): Transform;
declare function createGroup(): Array<{
    [key: string]: TextLineSpacingCommand;
}>;
export declare class TextLineSpacingCommand extends UICommand {
    _lineSpacing?: string;
    static readonly createGroup: typeof createGroup;
    constructor(lineSpacing?: string);
    isActive: (state: EditorState) => boolean;
    isEnabled: (state: EditorState) => boolean;
    waitForUserInput: (_state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, _event?: React.SyntheticEvent) => Promise<undefined>;
    executeWithUserInput: (_state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, _inputs?: string) => boolean;
    cancel(): void;
    execute: (state: EditorState, dispatch?: (tr: Transform) => void, _view?: EditorView) => boolean;
    renderLabel(): any;
    executeCustom: (_state: EditorState, tr: Transform) => Transform;
    executeCustomStyleForTable: (_state: EditorState, tr: Transform, _from: number, _to: number) => Transform;
}
export {};
