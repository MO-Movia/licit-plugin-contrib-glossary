import { EditorState } from 'prosemirror-state';
import { Schema } from 'prosemirror-model';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
type UpdateIntendType = {
    tr: Transform;
    docChanged: boolean;
};
export declare function updateIndentLevel(state: EditorState, tr: Transform, schema: Schema, delta: number, view: EditorView): UpdateIntendType;
export declare function setListNodeIndent(state: EditorState, tr: Transform, schema: Schema, pos: number, delta: number): Transform;
export declare function setNodeIndentMarkup(_state: EditorState, tr: Transform, pos: number, delta: number, _view?: EditorView): UpdateIntendType;
export {};
