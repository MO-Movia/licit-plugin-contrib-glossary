import { BULLET_LIST } from './NodeNames';
export function isBulletListNode(node) {
    return node.type.name === BULLET_LIST;
}
