import { TextSelection } from 'prosemirror-state';
import * as React from 'react';
import { MARK_FONT_TYPE } from './MarkNames';
import { applyMark, updateMarksAttrs } from './applyMark';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
function setFontType(tr, state, schema, name, isCustomStyleApplied) {
    const markType = schema.marks[MARK_FONT_TYPE];
    if (!markType) {
        return tr;
    }
    const attrs = name ? { name: name, overridden: !isCustomStyleApplied } : null;
    tr = applyMark(tr, schema, markType, attrs, isCustomStyleApplied);
    if (undefined === isCustomStyleApplied) {
        updateMarksAttrs(markType, tr, state, name);
    }
    return tr;
}
export class FontTypeCommand extends UICommand {
    _label = null;
    _name = '';
    _popUp = null;
    constructor(name) {
        super();
        this._name = name;
        this._label = name ? React.createElement("span", { style: { fontFamily: name } }, name) : null;
    }
    renderLabel = (_state) => {
        return this._label;
    };
    isEnabled = (state) => {
        const { schema, selection, tr } = state;
        const markType = schema.marks[MARK_FONT_TYPE];
        if (!markType) {
            return false;
        }
        const { from, to } = selection;
        if (to === from + 1) {
            const node = tr.doc.nodeAt(from);
            if (node.isAtom && !node.isText && node.isLeaf) {
                // An atomic node (e.g. Image) is selected.
                return false;
            }
        }
        return true;
    };
    execute = (state, dispatch, _view) => {
        const { schema } = state;
        // commnted selection because selection removes the storedMarks;
        // {selection}
        const tr = setFontType(state.tr, state, schema, this._name);
        if (tr.docChanged || tr.storedMarksSet) {
            // If selection is empty, the color is added to `storedMarks`, which
            // works like `toggleMark`
            // (see https://prosemirror.net/docs/ref/#commands.toggleMark).
            dispatch?.(tr);
            return true;
        }
        return false;
    };
    // [FS] IRAD-1087 2020-10-01
    // Method to execute custom styling implementation of font type
    executeCustom = (state, tr, from, to) => {
        const { schema } = state;
        tr = setFontType(tr.setSelection(TextSelection.create(tr.doc, from, to)), state, schema, this._name, true);
        return tr;
    };
    executeCustomStyleForTable = (state, tr, from, to) => {
        const { schema } = state;
        tr = setFontType(tr.setSelection(TextSelection.create(tr.doc, from, to)), state, schema, this._name, true);
        return tr;
    };
    waitForUserInput = (_state, _dispatch, _view, _event) => {
        return Promise.resolve(undefined);
    };
    executeWithUserInput = (_state, _dispatch, _view, _inputs) => {
        return false;
    };
    cancel() {
        return null;
    }
    isActive() {
        return true;
    }
}
