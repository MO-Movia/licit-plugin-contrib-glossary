let styles = [];
export function setRuntime(runtime) {
    // This function is intentionally empty. It serves as a placeholder for future development.
    // Add code here as needed.
    RuntimeService.Runtime = runtime;
}
export class RuntimeService {
    static runtime;
    static get Runtime() {
        return this.runtime;
    }
    static set Runtime(runtime) {
        this.runtime = runtime;
    }
}
export function getStyleByName(styleName) {
    return styles?.find((style) => style.styleName === styleName) || null;
}
export function setCustomStyles(styleList = []) {
    styles = styleList;
}
