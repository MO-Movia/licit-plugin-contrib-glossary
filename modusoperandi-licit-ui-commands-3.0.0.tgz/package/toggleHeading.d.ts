import { Schema } from 'prosemirror-model';
import { Transform } from 'prosemirror-transform';
export declare function toggleHeading(tr: Transform, schema: Schema, level: number): Transform;
export declare function setHeadingNode(tr: Transform, schema: Schema, pos: number, level?: number): Transform;
