import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import * as React from 'react';
export declare class FontSizeCommand extends UICommand {
    _popUp: any;
    _pt: number;
    constructor(pt: number);
    isEnabled: (state: EditorState) => boolean;
    waitForUserInput: (_state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, _event?: React.SyntheticEvent) => Promise<undefined>;
    executeWithUserInput: (_state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, _inputs?: string) => boolean;
    cancel(): void;
    execute: (state: EditorState, dispatch?: (tr: Transform) => void) => boolean;
    executeCustom: (state: EditorState, tr: Transform, from: number, to: number) => Transform;
    executeCustomStyleForTable: (state: EditorState, tr: Transform, from: number, to: number) => Transform;
    isActive(): boolean;
    renderLabel(): any;
}
