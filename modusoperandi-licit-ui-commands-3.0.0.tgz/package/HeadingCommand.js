import { toggleHeading } from './toggleHeading';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
export class HeadingCommand extends UICommand {
    _level;
    constructor(level) {
        super();
        this._level = level;
    }
    isActive = (_state) => {
        return true;
    };
    execute = (state, dispatch, _view) => {
        const { schema, selection } = state;
        const tr = toggleHeading(state.tr.setSelection(selection), schema, this._level);
        if (tr.docChanged) {
            dispatch?.(tr);
            return true;
        }
        else {
            return false;
        }
    };
    waitForUserInput = (_state, _dispatch, _view, _event) => {
        return Promise.resolve(undefined);
    };
    executeWithUserInput = (_state, _dispatch, _view, _inputs) => {
        return false;
    };
    cancel() {
        return null;
    }
    renderLabel = () => {
        return null;
    };
    executeCustom = (_state, tr) => {
        return tr;
    };
    executeCustomStyleForTable = (_state, tr, _from, _to) => {
        return tr;
    };
}
