import { Node } from 'prosemirror-model';
export declare function isOrderedListNode(node: Node): boolean;
