import { EditorState } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
import * as React from 'react';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
export declare class IndentCommand extends UICommand {
    _delta: number;
    constructor(delta: number);
    isActive: (_state: EditorState) => boolean;
    execute: (state: EditorState, dispatch?: (tr: Transform) => void, _view?: EditorView) => boolean;
    executeCustom: (state: EditorState, tr: Transform, from: number, to: number) => Transform;
    executeCustomStyleForTable: (state: EditorState, tr: Transform, _from: number, _to: number) => Transform;
    waitForUserInput: (_state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, _event?: React.SyntheticEvent) => Promise<undefined>;
    executeWithUserInput: (_state: EditorState, _dispatch?: (tr: Transform) => void, _view?: EditorView, _inputs?: string) => boolean;
    cancel(): void;
    renderLabel(): any;
}
