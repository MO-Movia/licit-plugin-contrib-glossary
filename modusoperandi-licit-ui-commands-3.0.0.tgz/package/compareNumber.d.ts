export declare function compareNumber(a: number, b: number): number;
