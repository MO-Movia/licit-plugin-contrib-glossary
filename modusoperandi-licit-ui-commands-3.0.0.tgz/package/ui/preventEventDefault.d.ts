import * as React from 'react';
export declare function preventEventDefault(e: React.SyntheticEvent): void;
