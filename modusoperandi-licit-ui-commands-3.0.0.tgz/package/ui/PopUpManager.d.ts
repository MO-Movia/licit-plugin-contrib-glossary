import type { PositionHandler } from './PopUpPosition';
import type { Rect } from './rects';
export type PopUpDetails = {
    anchor?: HTMLElement;
    anchorRect?: Rect;
    autoDismiss: boolean;
    body?: HTMLElement;
    bodyRect?: Rect;
    close: (val: any) => void;
    modal: boolean;
    position: PositionHandler;
    popupId: string;
};
export type PopUpBridge = {
    getDetails: () => PopUpDetails;
};
export declare class PopUpManager {
    _bridges: Map<any, any>;
    _positions: Map<any, any>;
    isColorPicker: boolean;
    _mx: number;
    _my: number;
    _rafID: number;
    register(bridge: PopUpBridge): void;
    unregister(bridge: PopUpBridge): void;
    _observe(): void;
    _unobserve(): void;
    _onScroll: (_e: Event) => void;
    _onResize: (_e: Event) => void;
    _onMouseChange: (e: MouseEvent) => void;
    _onClick: (e: MouseEvent) => void;
    _syncPosition: () => void;
}
declare const instance: PopUpManager;
export default instance;
