import type { Rect } from './rects';
export type PositionHandler = (anchorRect?: Rect, bodyRect?: Rect) => Rect;
export declare function atAnchorBottomLeft(anchorRect?: Rect, bodyRect?: Rect): Rect;
export declare function atAnchorBottomCenter(anchorRect?: Rect, bodyRect?: Rect): Rect;
export declare function atAnchorRight(anchorRect?: Rect, bodyRect?: Rect): Rect;
export declare function atViewportCenter(_anchorRect?: Rect, bodyRect?: Rect): Rect;
export declare function atAnchorTopRight(anchorRect?: Rect, bodyRect?: Rect): Rect;
export declare function atAnchorTopCenter(anchorRect?: Rect, bodyRect?: Rect): Rect;
