import * as React from 'react';
import { EditorView } from 'prosemirror-view';
import { UICommand } from '@modusoperandi/licit-doc-attrs-step';
export type PointerSurfaceProps = {
    active?: boolean;
    children?: any;
    className?: string;
    disabled?: boolean;
    id?: string;
    onClick?: (val: any, e: React.SyntheticEvent) => void;
    onMouseEnter?: (val: any, e: React.SyntheticEvent) => void;
    style?: Record<string, unknown>;
    title?: string;
    value?: string | number | Record<string, unknown> | EditorView | UICommand;
    hasChild?: boolean;
};
export declare class PointerSurface extends React.PureComponent {
    props: PointerSurfaceProps;
    _clicked: boolean;
    _mul: boolean;
    _pressedTarget: any;
    state: {
        pressed: boolean;
    };
    render(): React.ReactElement;
    componentWillUnmount(): void;
    _onMouseEnter: (e: React.SyntheticEvent) => void;
    _onMouseLeave: (e: React.MouseEvent) => void;
    _onMouseDown: (e: React.MouseEvent) => void;
    _onMouseUp: (e: React.SyntheticEvent) => void;
    _onMouseUpCapture: (e: MouseEvent) => void;
}
