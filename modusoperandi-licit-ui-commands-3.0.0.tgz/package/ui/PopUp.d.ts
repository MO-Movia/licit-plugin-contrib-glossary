import * as React from 'react';
import type { PopUpDetails } from './PopUpManager';
import type { Rect } from './rects';
type PositionHandler = (anchorRect?: Rect, bodyRect?: Rect) => Rect;
export type ViewProps = Record<string, unknown>;
export type PopUpParams = {
    anchor?: any;
    autoDismiss?: boolean;
    container?: Element;
    modal?: boolean;
    onClose?: (val: any) => void;
    position?: PositionHandler;
    IsChildDialog?: boolean;
    popUpId?: string;
    contextPos?: {
        x: number;
        y: number;
    };
};
export type PopUpProps = {
    View: typeof React.PureComponent;
    close: () => void;
    popUpParams: PopUpParams;
    viewProps: Record<string, unknown>;
};
export type PopUpHandle = {
    close: (val: any) => void;
    update: (props: Record<string, unknown>) => void;
};
export declare class PopUp extends React.PureComponent<PopUpProps> {
    props: PopUpProps;
    _bridge: any;
    _id: string;
    render(): React.ReactElement<HTMLDivElement>;
    componentDidMount(): void;
    componentWillUnmount(): void;
    _getDetails: () => PopUpDetails;
}
export {};
