import * as React from 'react';
import PopUpManager from './PopUpManager';
import { atAnchorBottomLeft, atViewportCenter } from './PopUpPosition';
import { uuid } from './uuid';
export class PopUp extends React.PureComponent {
    _bridge = null;
    _id = uuid();
    render() {
        const dummy = {};
        const { View, viewProps, close } = this.props;
        return (React.createElement("div", { "data-pop-up-id": this._id, id: this._id },
            React.createElement(View, { ...(viewProps || dummy), close: close })));
    }
    componentDidMount() {
        this._bridge = { getDetails: this._getDetails };
        PopUpManager.register(this._bridge);
    }
    componentWillUnmount() {
        if (this._bridge) {
            PopUpManager.unregister(this._bridge);
        }
    }
    _getDetails = () => {
        const { close, popUpParams } = this.props;
        const { anchor, autoDismiss, position, modal, popUpId } = popUpParams;
        return {
            anchor,
            autoDismiss: autoDismiss !== false,
            body: document.getElementById(this._id),
            close,
            modal: modal === true,
            position: position || (modal ? atViewportCenter : atAnchorBottomLeft),
            popupId: popUpId,
        };
    };
}
