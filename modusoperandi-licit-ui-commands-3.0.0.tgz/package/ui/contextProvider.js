import React, { createContext, Component } from 'react';
// Create a context with a default theme
const ThemeContext = createContext('light');
// Define a provider component that will wrap your application
class ThemeProvider extends Component {
    render() {
        const { children, theme } = this.props;
        return (React.createElement(ThemeContext.Provider, { value: theme }, children));
    }
}
export { ThemeProvider, ThemeContext };
