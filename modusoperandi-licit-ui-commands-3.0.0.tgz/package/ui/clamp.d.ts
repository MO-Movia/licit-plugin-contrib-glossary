export declare function clamp(min: number, val: number, max: number): number;
