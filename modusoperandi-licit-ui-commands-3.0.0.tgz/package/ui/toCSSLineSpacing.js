// Line spacing names and their values.
export const LINE_SPACING_100 = '125%';
export const LINE_SPACING_115 = '138%';
export const LINE_SPACING_150 = '165%';
export const LINE_SPACING_200 = '232%';
export const SINGLE_LINE_SPACING = LINE_SPACING_100;
export const DOUBLE_LINE_SPACING = LINE_SPACING_200;
// Normalize the css line-height vlaue to percentage-based value if applicable.
// Also, it calibrates the incorrect line spacing value exported from Google
// Doc.
export function toCSSLineSpacing(source) {
    if (!source) {
        return '';
    }
    let strValue = String(source);
    // e.g. line-height: 1.5;
    const numValue = parseFloat(strValue);
    const lastChar = strValue[strValue.length - 1];
    // can parse number and last char is a number
    if (!Number.isNaN(numValue) && '0' <= lastChar && lastChar <= '9') {
        strValue = String(Math.round(numValue * 100)) + '%';
    }
    // Google Doc exports line spacing with wrong values. For instance:
    // - Single => 100%
    // - 1.15 => 115%
    // - Double => 200%
    // But the actual CSS value measured in Google Doc is like this:
    // - Single => 125%
    // - 1.15 => 138%
    // - Double => 232%
    // The following `if` block will calibrate the value if applicable.
    if (strValue === '100%') {
        return LINE_SPACING_100;
    }
    if (strValue === '115%') {
        return LINE_SPACING_115;
    }
    if (strValue === '150%') {
        return LINE_SPACING_150;
    }
    if (strValue === '200%') {
        return LINE_SPACING_200;
    }
    // e.g. line-height: 15px;
    return strValue;
}
// [FS] IRAD-1104 2020-11-13
// Issue fix : Linespacing Double and Single not applied in the sample text paragraph
export function getLineSpacingValue(lineSpacing) {
    let _lineSpaceValue = '';
    switch (lineSpacing) {
        case 'Single':
            _lineSpaceValue = SINGLE_LINE_SPACING;
            break;
        case '1.15':
            _lineSpaceValue = LINE_SPACING_115;
            break;
        case '1.5':
            _lineSpaceValue = LINE_SPACING_150;
            break;
        case 'Double':
            _lineSpaceValue = DOUBLE_LINE_SPACING;
            break;
        default:
            _lineSpaceValue = SINGLE_LINE_SPACING;
            break;
    }
    return _lineSpaceValue;
}
