import * as React from 'react';
type TooltipSurfaceProps = {
    tooltip: string;
    children?: any;
};
export declare class TooltipSurface extends React.PureComponent<TooltipSurfaceProps> {
    _id: string;
    _popUp: any;
    props: {
        tooltip: string;
        children?: any;
    };
    componentWillUnmount(): void;
    render(): React.ReactElement;
    _onMouseEnter: (e: any) => void;
    _onMouseLeave: () => void;
    _onClose: () => void;
}
export {};
