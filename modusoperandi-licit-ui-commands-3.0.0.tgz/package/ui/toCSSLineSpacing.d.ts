export declare const LINE_SPACING_100 = "125%";
export declare const LINE_SPACING_115 = "138%";
export declare const LINE_SPACING_150 = "165%";
export declare const LINE_SPACING_200 = "232%";
export declare const SINGLE_LINE_SPACING = "125%";
export declare const DOUBLE_LINE_SPACING = "232%";
export declare function toCSSLineSpacing(source: string): string;
export declare function getLineSpacingValue(lineSpacing: string): string;
