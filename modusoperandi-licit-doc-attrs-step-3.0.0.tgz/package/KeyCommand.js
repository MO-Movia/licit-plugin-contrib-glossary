import { PluginKey } from 'prosemirror-state';
import { keymap } from 'prosemirror-keymap';
export function makeKeyMap(description, windows, mac, common) {
    return {
        description: description,
        windows: windows,
        mac: mac,
        common: common,
    };
}
export function makeKeyMapWithCommon(description, common) {
    const windows = common.replace(/Mod/i, 'Ctrl');
    const mac = common.replace(/Mod/i, 'Cmd');
    return makeKeyMap(description, windows, mac, common);
}
// [FS] IRAD-1005 2020-07-07
// Upgrade outdated packages.
// set plugin keys so that to avoid duplicate key error when keys are assigned automatically.
export function setPluginKey(plugin, key) {
    if (plugin?.spec) {
        plugin.spec.key = new PluginKey(key + 'Plugin');
        if (plugin.spec.key) {
            plugin.key = plugin.spec.key.key;
        }
    }
    return plugin;
}
export function createKeyMapPlugin(pluginKeyMap, name) {
    return setPluginKey(keymap(pluginKeyMap), name);
}
