import { Editor } from '@tiptap/core';
import { EditorState, Selection } from 'prosemirror-state';
import { Transform } from 'prosemirror-transform';
import { EditorView } from 'prosemirror-view';
export type IsActiveCall = (state: EditorState) => boolean;
export type FindNodeTypeInSelectionCall = (selection: Selection) => Record<string, unknown>;
export declare const EventType: {
    CLICK: string;
    MOUSEENTER: string;
};
export declare abstract class UICommand {
    static readonly EventType: {
        CLICK: string;
        MOUSEENTER: string;
    };
    static theme: string;
    protected _editor: Editor | null;
    get editor(): Editor | null;
    set editor(editor: Editor);
    shouldRespondToUIEvent: (e: any) => boolean;
    renderLabel(state?: EditorState): unknown;
    isActive(_state?: EditorState): boolean;
    isEnabled: (state: EditorState, view?: EditorView) => boolean | Transform;
    dryRun: (state: EditorState, view?: EditorView) => boolean | Transform;
    dryRunEditorStateProxyGetter: (state: any, propKey: string) => any;
    dryRunEditorStateProxySetter: (state: any, propKey: string, propValue: any) => boolean;
    execute: (state: EditorState, dispatch?: (tr: Transform) => void, view?: EditorView, event?: any) => Transform | boolean;
    abstract waitForUserInput(state: EditorState, dispatch?: (tr: Transform) => void, view?: EditorView, event?: any): Promise<any>;
    abstract executeWithUserInput(state: EditorState, dispatch?: (tr: Transform) => void, view?: EditorView, inputs?: any): boolean;
    abstract cancel(): void;
    abstract executeCustom(state: EditorState, tr: Transform, from: number, to: number): Transform;
    abstract executeCustomStyleForTable(state: EditorState, tr: Transform, from: number, to: number): Transform;
}
