import { Step, StepResult } from 'prosemirror-transform';
type SetDocAttrStepJSONValue = {
    key: string;
    stepType: string;
    value: any;
};
export declare class SetDocAttrStep extends Step {
    key: string;
    stepType: string;
    value: any;
    prevValue: any;
    constructor(key: string, value: any, stepType?: string);
    apply(doc: any): StepResult;
    invert(): SetDocAttrStep;
    map(): this;
    merge(other: SetDocAttrStep): SetDocAttrStep | null;
    toJSON(): SetDocAttrStepJSONValue;
    static fromJSON(_schema: any, json: SetDocAttrStepJSONValue): SetDocAttrStep;
    static register(): boolean;
}
export {};
